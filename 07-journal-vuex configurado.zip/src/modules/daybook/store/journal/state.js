

export default () => ({
    isLoading: true,
    entries: [
        {
            id: new Date().getTime(),
            date: new Date().toDateString(),
            text: 'Veniam enim consectetur voluptate ad occaecat occaecat proident veniam esse adipisicing. Mollit fugiat amet quis ad elit enim nulla exercitation eu exercitation. Mollit sit consectetur deserunt ullamco enim cupidatat est. Irure et consectetur elit occaecat ullamco nulla quis.',
            picture: null,
        },
        {
            id: new Date().getTime() + 1000,
            date: new Date().toDateString(),
            text: 'Adipisicing irure exercitation ipsum id fugiat sit occaecat culpa cupidatat. Elit labore exercitation duis ea dolor laboris duis ea Lorem minim. Cillum magna mollit eiusmod nulla consectetur nostrud est.',
            picture: null,
        },
        {
            id: new Date().getTime() + 2000,
            date: new Date().toDateString(),
            text: 'Ut Lorem consequat pariatur sit cillum deserunt. Dolore est cupidatat officia labore aliquip veniam tempor nostrud sunt velit enim cupidatat. Dolore in consequat eiusmod ea elit mollit ex sunt voluptate nulla consectetur cillum. Officia sunt proident sint aliquip occaecat nulla elit esse anim adipisicing cupidatat dolor. Ullamco aliqua labore dolor fugiat cupidatat officia officia culpa. Ea adipisicing excepteur minim consectetur ad minim.',
            picture: null,
        },
    ]
})