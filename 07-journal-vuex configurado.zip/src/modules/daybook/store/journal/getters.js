

export const getEntriesByTerm = (state) => {
    
}

export const getEntryById= (state) => {
    
}