

export const setEntries = (state) => {

}

export const updateEntry = (state) => {

}

export const createEntry = (state) => {

}