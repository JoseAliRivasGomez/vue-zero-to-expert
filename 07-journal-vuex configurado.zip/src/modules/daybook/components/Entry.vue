<template>
  <div class="entry-container mb-3 pointer p-2" @click="$router.push({name: 'entry', params: {id: 1}})">
    <div class="entry-title d-flex">
        <span class="text-success fs-5 fw-bold">15</span>
        <span class="mx-1 fs-5">Julio</span>
        <span class="mx-2 fw-light">2021, jueves</span>
    </div>
    <div class="entry-description">
        Tempor cupidatat exercitation proident sint non cupidatat commodo pariatur tempor ut nostrud. Velit ex Lorem reprehenderit fugiat in nulla laborum adipisicing et ullamco. Non ipsum ex occaecat sit et quis commodo anim ut ut exercitation pariatur ad. Anim ad sint eiusmod nulla ex sunt et nisi. Culpa enim ipsum proident ea aliquip occaecat laborum nisi amet commodo voluptate est in. Eu dolor veniam eu veniam aliqua ut qui qui mollit commodo labore proident ex.
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

.entry-container{
    border-bottom: 1px solid #2c3e50;
    transition: 0.2s all  ease-in;

    &:hover{
        background-color: lighten($color: grey, $amount: 45);
        transition: 0.2s all  ease-in;
    }

    .entry-description{
        font-size: 12px;
    }
}



</style>